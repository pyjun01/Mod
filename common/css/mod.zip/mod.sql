-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- 생성 시간: 18-07-05 03:41
-- 서버 버전: 10.1.33-MariaDB
-- PHP 버전: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `mod`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `apply`
--

CREATE TABLE `apply` (
  `idx` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `borrow_bk` varchar(100) NOT NULL,
  `img` varchar(100) NOT NULL,
  `borrow_day` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `agree` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `apply`
--

INSERT INTO `apply` (`idx`, `name`, `borrow_bk`, `img`, `borrow_day`, `agree`) VALUES
(1, '관리자', '자바스크립트 정복', 'js.jpg', '2016-10-17 08:40:15', 'yes'),
(2, '', '제대로 배우는 Node.js 프로그래밍', 'node.jpg', '2016-10-18 00:59:08', 'no'),
(3, '', 'HTML5 + CSS3 웹표준의 정석', 'html.jpg', '2016-10-18 00:59:18', 'no');

-- --------------------------------------------------------

--
-- 테이블 구조 `board`
--

CREATE TABLE `board` (
  `idx` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `contents` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hit` int(11) NOT NULL,
  `board_owner` varchar(100) NOT NULL,
  `board_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `board_file`
--

CREATE TABLE `board_file` (
  `idx` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_extension` varchar(255) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `post_idx` int(11) NOT NULL,
  `down` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `board_list`
--

CREATE TABLE `board_list` (
  `idx` int(11) NOT NULL,
  `board_name` varchar(100) NOT NULL,
  `board_owner` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `board_list`
--

INSERT INTO `board_list` (`idx`, `board_name`, `board_owner`) VALUES
(1, 'q', '박용준'),
(2, 'w', '박용준'),
(3, 'ㅂㅈㄷ', '박용준'),
(7, 'e', '박용준'),
(8, 'asd', '박용준'),
(9, 'q', '박박박');

-- --------------------------------------------------------

--
-- 테이블 구조 `books`
--

CREATE TABLE `books` (
  `idx` int(11) NOT NULL,
  `book_name` varchar(100) NOT NULL,
  `borrow` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `publisher` varchar(100) NOT NULL,
  `img` varchar(100) NOT NULL,
  `borrower_idx` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `books`
--

INSERT INTO `books` (`idx`, `book_name`, `borrow`, `author`, `publisher`, `img`, `borrower_idx`) VALUES
(1, 'HTML5 + CSS3 웹표준의 정석', 'yes', '고경희', '이지스퍼블리싱', 'html.jpg', 21),
(2, 'java script + jquery 입문', 'yes', '정인용', '이지스퍼블리싱', 'js.jpg', 0),
(3, 'Angular js 인 액션', 'yes', '루카스 루벨키, 브라이언 포드', '제이펍', 'angjs.jpg', 21),
(4, '토비의 스프링', 'no', '이일민', '에이콘출판사', 'spring.jpg', 0),
(5, 'jquery 완전 정복 시리즈1', 'no', '김춘경', '위키북스', 'jquery1.jpg', 0),
(6, 'jquery 완전 정복 시리즈2', 'no', '김춘경', '위키북스', 'jquery2.jpg', 0),
(7, 'jquery 완전 정복 시리즈3', 'no', '김춘경', '위키북스', 'jquery3.jpg', 0),
(8, 'Modern PHP', 'no', '조시 록하트', '한빛미디어', 'php.jpg', 0);

-- --------------------------------------------------------

--
-- 테이블 구조 `content`
--

CREATE TABLE `content` (
  `idx` int(11) NOT NULL,
  `title` text NOT NULL,
  `text` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `content`
--

INSERT INTO `content` (`idx`, `title`, `text`) VALUES
(27, '바굥준', '2018-01-19\r\n오후 7시 13분'),
(31, '2018 01 19', 'O'),
(32, '아싸', '10만원 아꼈다 ㄱㅇㄷ\r\n-ㅂㅎㅈ'),
(33, '2018 01 20', 'X'),
(34, '김우너길', '김원길 '),
(35, '바굥주니', '바굥바굥바굥주니'),
(42, '.htaccess', 'RewriteEngine On\r\nRewriteRule ^([^.]+)/?$ index.php?url=$1 [L,QSA]'),
(44, '영화', '이상한나라의 앨리스\r\n거울나라의 앨리스\r\n밀정\r\n유주얼서스팩트\r\n마이너리티 리포트\r\n인셉션\r\n위플래쉬\r\n브이 포 벤데타\r\n킹스맨\r\n레미제라블\r\n인터스텔라\r\n나는 전설이다\r\n미스트\r\n식스센스\r\n해빙\r\n이터널 선샤이\r\n살인자의 기억법'),
(45, '맛집', '타노시\r\n장위똥돼지\r\n영금정등대게\r\n담소사골순대\r\n에베레스트\r\n밀밭식당\r\n로지라멘\r\n플라잉볼\r\n라멘트럭'),
(53, 'PHP db문', '$db = new PDO(\'mysql:host=localhost;dbname=;charset=utf8\', \'root\', \'\');\r\n'),
(56, 'jquery주소', 'http://code.jquery.com/jquery-3.2.1.js'),
(57, 'dothome 주소', 'pyjun01.dothome.co.kr\r\npyjun02.dothome.co.kr'),
(58, '이정헌', '왔다감'),
(59, 'id', '1. 생일축하 웹사이트\r\n//대충 구상\r\n들어가면 code값을 받아서 그코드에서 오늘날짜와 몇번째 생일인지 받아와서\r\n사이트를 들어가면\r\n당신의 @@번째 생일을 진심으로 축하합니다라는 문구가 나오면서\r\n유명인들이축하합니다얘기하는 영상이 자동으로 틀어짐\r\n//구체적으로 구상\r\n검은화면 버튼누르면 화면이 밝아지더니 가운데에 조명효과가 들어옴 그리고 위에서 박스가 하나 떨어짐 그리고 박스위에 멘트뜨고 풍선띄움 그리고 가운데 박스에 축하영상이 틀어짐\r\n\r\nhttps://www.google.com/search?biw=1680&bih=919&tbm=isch&sa=1&ei=FvB2Wt6FKILg0gTs1LTQDA&q=%ED%92%8D%EC%84%A0+%EC%9D%BC%EB%9F%AC%EC%8A%A4%ED%8A%B8&oq=%ED%92%8D%EC%84%A0+&gs_l=psy-ab.3.0.0l10.11639.11926.0.12997.3.3.0.0.0.0.95.279.3.3.0....0...1c.1.64.psy-ab..0.2.188...0i13k1.0.y7uXHYCfPbI'),
(60, 'id', '그림판만들어보기'),
(61, '보안', 'xss\r\nsql injection'),
(62, '배울거', 'react(x) vue(o)\r\nmvc\r\nnode.js(+es6)\r\npython(+django)'),
(63, '모질라', 'https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Building_blocks/Looping_code'),
(71, 'indexedDB', 'var db;\r\nvar request = window.indexedDB.open(\'first_db\', 1);\r\n//성공 or 실패 //시작할때 불러오는건 success안에\r\nrequest.onsuccess = function() {\r\n  db = request.result;\r\n}\r\nrequest.onerror = function() {\r\n  alert(\'DB error\');\r\n}\r\nrequest.onupgradeneeded = function(event) {\r\n  var result = event.target.result;\r\n  var store = result.createObjectStore(\'dbname\', {\r\n    \'keyPath\': \'id\',\r\n    \'autoIncrement\': \'auto\'\r\n  });\r\n}\r\n//공통으로 \r\nvar store = db.transaction([\'dbname\'],\'readwrite\').objectStore(\'dbname\');\r\n//DB에 추가함\r\n$(\'#btn\').on(\'click\', function() {\r\n\r\n  store.add({\r\n    \'value\': $(\'input\').val()\r\n  });\r\n});\r\n//DB에서 가져옴\r\n  var request = store.get(key);\r\n  request.onsuccess = function() {\r\n    var result = request.result;\r\n  }\r\n//DB에서 정보를 지움\r\n  var request = store.delete(key);\r\n//DB에 정보를 덮어씀\r\n  var request = store.put({\r\n    id: key,\r\n    value: $(\'input\').val()\r\n  });'),
(72, 'id', '질문{\r\n혹시 코드를 짜는 걸 가르쳐주는 강의 말고요, \r\n실제 코드를 말로 풀어주어 배우는 사람이 프로그래밍적인 기획과 아이디어에 다가갈 수 있게 해주는 강좌같은게 있을까요? 그런 강의 들으면 참 재미있을거 같아서요.}\r\n\r\n한번해보자 나중에'),
(73, 'id', 'codepen만들기'),
(74, 'twitch api', 'https://dev.twitch.tv/api'),
(75, 'id', '학교급식\r\n학교시간표\r\n프로그레시브 웹 앱스를 사용해보자'),
(77, 'id', '밤쯤에 알림이 와서 오늘하루 뭘먹고 먹는곳에 얼마를썻는지를 기록하게해보자'),
(79, 'id', '일렉트론을 이용해서 랜덤채팅을 만들어보자'),
(80, 'id', '카카오톡 챗봇으로 학교급식'),
(81, 'id', '카카오톡 챗봇 아침마다 카톡으로 급식메뉴 알려주기'),
(82, 'id', 'pwa를 이용해서 기능반 당번만들기'),
(83, '대회 끝나고 할거', '일렉트론,\r\n프로그레시브 웹,\r\nNode.js,\r\nes6,\r\nreact,\r\n\r\npython,\r\nDjango,\r\n\r\ngit bash command,\r\n\r\n'),
(85, 'id', '제비뽑기, 주사위, 야바위, 사다리타기, 홀짝, 돌림판 만들기');

-- --------------------------------------------------------

--
-- 테이블 구조 `file`
--

CREATE TABLE `file` (
  `idx` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `time` datetime NOT NULL,
  `down` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `information`
--

CREATE TABLE `information` (
  `email` varchar(20) NOT NULL,
  `id` varchar(10) NOT NULL,
  `pw` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `information`
--

INSERT INTO `information` (`email`, `id`, `pw`) VALUES
('qwe', 'pyongj0502', 'pyj050201240924'),
('qwe', 'qwer', 'asdf');

-- --------------------------------------------------------

--
-- 테이블 구조 `notice`
--

CREATE TABLE `notice` (
  `idx` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `noticeboard`
--

CREATE TABLE `noticeboard` (
  `idx` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `contents` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `noticeboard`
--

INSERT INTO `noticeboard` (`idx`, `title`, `contents`, `name`, `date`, `hit`) VALUES
(1, '안녕하세요 모드 홈페이지가 다시 개발되었습니다.', '안녕하세요 관리자 입니다.\r\n모드 홈페이지를 다시 개발하게 되었습니다.\r\n', '관리자', '2017-06-30 02:31:56', 16),
(2, '안녕하세요 MOD 입니다.', 'MOD', '관리자', '2017-07-07 06:37:32', 8),
(3, '안녕하세요', '안녕하세요', '관리자', '2017-07-07 07:14:34', 10),
(4, 'q', 'q', '박박박', '2018-07-03 12:09:41', 2),
(5, 'q', 'q', '박용준', '2018-07-04 23:59:27', 1);

-- --------------------------------------------------------

--
-- 테이블 구조 `user`
--

CREATE TABLE `user` (
  `idx` int(11) NOT NULL,
  `name` varchar(10) NOT NULL,
  `id` varchar(100) NOT NULL,
  `pw` varchar(100) NOT NULL,
  `grade` varchar(5) NOT NULL,
  `phone_num` varchar(11) NOT NULL,
  `agree` int(1) NOT NULL DEFAULT '0',
  `user_level` int(11) NOT NULL DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `user`
--

INSERT INTO `user` (`idx`, `name`, `id`, `pw`, `grade`, `phone_num`, `agree`, `user_level`, `date`) VALUES
(5, '서재우', 'wodn2828', 'wodn4563', '10415', '01071934906', 1, 1, '0000-00-00 00:00:00'),
(6, '김민석', 'ohwhos', '1234', '30605', '01095861751', 1, 0, '0000-00-00 00:00:00'),
(7, '이예진', 'yejin0307', 'asdzxc', '10603', '01050022735', 1, 0, '0000-00-00 00:00:00'),
(8, '이예진', 'Leeyejin', 'yejin99', '20505', '01050022735', 1, 0, '0000-00-00 00:00:00'),
(10, '김수인', 'asdfgh', 'asdf123', '12345', '01012345678', 1, 0, '0000-00-00 00:00:00'),
(13, '읭읭이', 'dmlddmlddl', 'dmlddmlddl', '99999', '01099999999', 1, 0, '0000-00-00 00:00:00'),
(14, '관리자투', 'asd123', 'asd123', '30621', '01025236510', 1, 0, '2017-06-29 01:34:52'),
(18, '가가가가', 'admin568', 'sanghup1234', '20655', '01055558888', 1, 0, '2017-06-29 02:47:21'),
(20, '이항선', 'redhang07', 'redhang07', '40207', '01012345678', 1, 0, '2017-08-19 10:56:53'),
(21, '박용준', 'qwe123', 'qwe123', '20508', '01022059795', 1, 1, '2018-04-27 04:28:28'),
(22, '박박박', 'qwe123qwe', 'qwe123qwe', '10112', '01012312333', 1, 0, '2018-05-04 02:08:36');

-- --------------------------------------------------------

--
-- 테이블 구조 `user_connect`
--

CREATE TABLE `user_connect` (
  `idx` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `usertime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `user_connect`
--

INSERT INTO `user_connect` (`idx`, `username`, `userid`, `usertime`) VALUES
(21, '박용준', 'qwe123', '2018-06-20 22:48:19');

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `apply`
--
ALTER TABLE `apply`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `board`
--
ALTER TABLE `board`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `board_file`
--
ALTER TABLE `board_file`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `board_list`
--
ALTER TABLE `board_list`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `file`
--
ALTER TABLE `file`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `noticeboard`
--
ALTER TABLE `noticeboard`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `user_connect`
--
ALTER TABLE `user_connect`
  ADD PRIMARY KEY (`idx`);

--
-- 덤프된 테이블의 AUTO_INCREMENT
--

--
-- 테이블의 AUTO_INCREMENT `apply`
--
ALTER TABLE `apply`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 테이블의 AUTO_INCREMENT `board`
--
ALTER TABLE `board`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- 테이블의 AUTO_INCREMENT `board_file`
--
ALTER TABLE `board_file`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- 테이블의 AUTO_INCREMENT `board_list`
--
ALTER TABLE `board_list`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 테이블의 AUTO_INCREMENT `books`
--
ALTER TABLE `books`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 테이블의 AUTO_INCREMENT `content`
--
ALTER TABLE `content`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- 테이블의 AUTO_INCREMENT `file`
--
ALTER TABLE `file`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- 테이블의 AUTO_INCREMENT `notice`
--
ALTER TABLE `notice`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `noticeboard`
--
ALTER TABLE `noticeboard`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- 테이블의 AUTO_INCREMENT `user`
--
ALTER TABLE `user`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- 테이블의 AUTO_INCREMENT `user_connect`
--
ALTER TABLE `user_connect`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
