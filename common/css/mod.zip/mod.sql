-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- 생성 시간: 18-07-03 16:53
-- 서버 버전: 10.1.29-MariaDB
-- PHP 버전: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `mod`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `apply`
--

CREATE TABLE `apply` (
  `idx` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `borrow_bk` varchar(100) NOT NULL,
  `img` varchar(100) NOT NULL,
  `borrow_day` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `agree` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `apply`
--

INSERT INTO `apply` (`idx`, `name`, `borrow_bk`, `img`, `borrow_day`, `agree`) VALUES
(1, '관리자', '자바스크립트 정복', 'js.jpg', '2016-10-17 08:40:15', 'yes'),
(2, '', '제대로 배우는 Node.js 프로그래밍', 'node.jpg', '2016-10-18 00:59:08', 'no'),
(3, '', 'HTML5 + CSS3 웹표준의 정석', 'html.jpg', '2016-10-18 00:59:18', 'no');

-- --------------------------------------------------------

--
-- 테이블 구조 `board`
--

CREATE TABLE `board` (
  `idx` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `contents` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hit` int(11) NOT NULL,
  `board_owner` varchar(100) NOT NULL,
  `board_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `board_file`
--

CREATE TABLE `board_file` (
  `idx` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_extension` varchar(255) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `post_name` varchar(100) NOT NULL,
  `down` int(11) NOT NULL,
  `time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `board_list`
--

CREATE TABLE `board_list` (
  `idx` int(11) NOT NULL,
  `board_name` varchar(100) NOT NULL,
  `board_owner` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `board_list`
--

INSERT INTO `board_list` (`idx`, `board_name`, `board_owner`) VALUES
(1, 'q', '박용준'),
(2, 'w', '박용준'),
(3, 'ㅂㅈㄷ', '박용준'),
(7, 'e', '박용준'),
(8, 'asd', '박용준'),
(9, 'q', '박박박');

-- --------------------------------------------------------

--
-- 테이블 구조 `books`
--

CREATE TABLE `books` (
  `idx` int(11) NOT NULL,
  `book_name` varchar(100) NOT NULL,
  `borrow` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `publisher` varchar(100) NOT NULL,
  `img` varchar(100) NOT NULL,
  `borrower_idx` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `books`
--

INSERT INTO `books` (`idx`, `book_name`, `borrow`, `author`, `publisher`, `img`, `borrower_idx`) VALUES
(1, 'HTML5 + CSS3 웹표준의 정석', 'yes', '고경희', '이지스퍼블리싱', 'html.jpg', 21),
(2, 'java script + jquery 입문', 'yes', '정인용', '이지스퍼블리싱', 'js.jpg', 0),
(3, 'Angular js 인 액션', 'yes', '루카스 루벨키, 브라이언 포드', '제이펍', 'angjs.jpg', 21),
(4, '토비의 스프링', 'no', '이일민', '에이콘출판사', 'spring.jpg', 0),
(5, 'jquery 완전 정복 시리즈1', 'no', '김춘경', '위키북스', 'jquery1.jpg', 0),
(6, 'jquery 완전 정복 시리즈2', 'no', '김춘경', '위키북스', 'jquery2.jpg', 0),
(7, 'jquery 완전 정복 시리즈3', 'no', '김춘경', '위키북스', 'jquery3.jpg', 0),
(8, 'Modern PHP', 'no', '조시 록하트', '한빛미디어', 'php.jpg', 0);

-- --------------------------------------------------------

--
-- 테이블 구조 `file`
--

CREATE TABLE `file` (
  `idx` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `time` datetime NOT NULL,
  `down` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `file`
--

INSERT INTO `file` (`idx`, `name`, `hash`, `time`, `down`) VALUES
(1, 'background.jpg', '3ec2fbc831596ce5da4d4e03f1bf3b2b.jpg', '2016-10-13 11:01:32', 0),
(2, 'AdCube - Adverting For Everyone.html', '80b535b95b25ed1b29ce0c690d97aab6.html', '2016-10-13 11:03:02', 1),
(3, 'background.jpg', '389d12e729054149999cda7128179180.jpg', '2016-10-13 11:05:59', 1),
(32, 'ddahyoni.jpg', '19000dd3b7028d2d6cb8b9d3bc70a3ac.jpg', '2018-04-27 06:59:01', 0),
(38, 'b', 'b', '2016-10-13 11:11:11', 0),
(39, 'strcmp.c', 'files', '0000-00-00 00:00:00', 0),
(40, '숙제ㅠㅠ.png', 'files', '2018-06-20 15:22:21', 0),
(41, '', 'files', '2018-06-20 15:25:49', 0),
(42, '34418506_1555759574522305_448807495268302848_n.jpg', 'files', '2018-06-20 15:30:19', 0),
(43, '', 'files', '2018-06-20 15:35:41', 0),
(44, 'script.js', 'files', '2018-07-03 14:09:41', 0);

-- --------------------------------------------------------

--
-- 테이블 구조 `notice`
--

CREATE TABLE `notice` (
  `idx` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `noticeboard`
--

CREATE TABLE `noticeboard` (
  `idx` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `contents` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `noticeboard`
--

INSERT INTO `noticeboard` (`idx`, `title`, `contents`, `name`, `date`, `hit`) VALUES
(1, '안녕하세요 모드 홈페이지가 다시 개발되었습니다.', '안녕하세요 관리자 입니다.\r\n모드 홈페이지를 다시 개발하게 되었습니다.\r\n', '관리자', '2017-06-30 02:31:56', 16),
(2, '안녕하세요 MOD 입니다.', 'MOD', '관리자', '2017-07-07 06:37:32', 8),
(3, '안녕하세요', '안녕하세요', '관리자', '2017-07-07 07:14:34', 10),
(4, 'q', 'q', '박박박', '2018-07-03 12:09:41', 1);

-- --------------------------------------------------------

--
-- 테이블 구조 `user`
--

CREATE TABLE `user` (
  `idx` int(11) NOT NULL,
  `name` varchar(10) NOT NULL,
  `id` varchar(100) NOT NULL,
  `pw` varchar(100) NOT NULL,
  `grade` varchar(5) NOT NULL,
  `phone_num` varchar(11) NOT NULL,
  `agree` int(1) NOT NULL DEFAULT '0',
  `user_level` int(11) NOT NULL DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `user`
--

INSERT INTO `user` (`idx`, `name`, `id`, `pw`, `grade`, `phone_num`, `agree`, `user_level`, `date`) VALUES
(5, '서재우', 'wodn2828', 'wodn4563', '10415', '01071934906', 1, 1, '0000-00-00 00:00:00'),
(6, '김민석', 'ohwhos', '1234', '30605', '01095861751', 1, 0, '0000-00-00 00:00:00'),
(7, '이예진', 'yejin0307', 'asdzxc', '10603', '01050022735', 1, 0, '0000-00-00 00:00:00'),
(8, '이예진', 'Leeyejin', 'yejin99', '20505', '01050022735', 1, 0, '0000-00-00 00:00:00'),
(10, '김수인', 'asdfgh', 'asdf123', '12345', '01012345678', 1, 0, '0000-00-00 00:00:00'),
(13, '읭읭이', 'dmlddmlddl', 'dmlddmlddl', '99999', '01099999999', 1, 0, '0000-00-00 00:00:00'),
(14, '관리자투', 'asd123', 'asd123', '30621', '01025236510', 1, 0, '2017-06-29 01:34:52'),
(18, '가가가가', 'admin568', 'sanghup1234', '20655', '01055558888', 1, 0, '2017-06-29 02:47:21'),
(20, '이항선', 'redhang07', 'redhang07', '40207', '01012345678', 1, 0, '2017-08-19 10:56:53'),
(21, '박용준', 'qwe123', 'qwe123', '20508', '01022059795', 1, 1, '2018-04-27 04:28:28'),
(22, '박박박', 'qwe123qwe', 'qwe123qwe', '10112', '01012312333', 1, 0, '2018-05-04 02:08:36');

-- --------------------------------------------------------

--
-- 테이블 구조 `user_connect`
--

CREATE TABLE `user_connect` (
  `idx` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `usertime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `user_connect`
--

INSERT INTO `user_connect` (`idx`, `username`, `userid`, `usertime`) VALUES
(21, '박용준', 'qwe123', '2018-06-20 22:48:19');

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `apply`
--
ALTER TABLE `apply`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `board`
--
ALTER TABLE `board`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `board_file`
--
ALTER TABLE `board_file`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `board_list`
--
ALTER TABLE `board_list`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `file`
--
ALTER TABLE `file`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `noticeboard`
--
ALTER TABLE `noticeboard`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`idx`);

--
-- 테이블의 인덱스 `user_connect`
--
ALTER TABLE `user_connect`
  ADD PRIMARY KEY (`idx`);

--
-- 덤프된 테이블의 AUTO_INCREMENT
--

--
-- 테이블의 AUTO_INCREMENT `apply`
--
ALTER TABLE `apply`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 테이블의 AUTO_INCREMENT `board`
--
ALTER TABLE `board`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `board_file`
--
ALTER TABLE `board_file`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `board_list`
--
ALTER TABLE `board_list`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 테이블의 AUTO_INCREMENT `books`
--
ALTER TABLE `books`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 테이블의 AUTO_INCREMENT `file`
--
ALTER TABLE `file`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- 테이블의 AUTO_INCREMENT `notice`
--
ALTER TABLE `notice`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `noticeboard`
--
ALTER TABLE `noticeboard`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- 테이블의 AUTO_INCREMENT `user`
--
ALTER TABLE `user`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- 테이블의 AUTO_INCREMENT `user_connect`
--
ALTER TABLE `user_connect`
  MODIFY `idx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
